#ifndef UTILITY_H
#define UTILITY_H

#include <stdio.h>
#include "player.h"

void savePlayerDataToFile();
void loadPlayerDataFromFile();

#endif