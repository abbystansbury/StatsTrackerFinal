#include <stdio.h>
#include "player.h"

void savePlayerDataToFile() {
    FILE *file = fopen("player_data.txt", "w");
    if (file == NULL) {
        printf("Error opening file for writing\n");
        return;
    }

    for (int i = 0; i < numPlayers; i++) {
        fprintf(file, "%s %d %d %d %d %d %d %d\n", players[i].name, players[i].pointsScored, players[i].steals, players[i].assists, players[i].blocks, players[i].turnovers, players[i].shotsMade, players[i].shotsAttempted);
    }

    fclose(file);
}

void loadPlayerDataFromFile() {
    FILE *file = fopen("player_data.txt", "r");
    if (file == NULL) {
        printf("Error opening file for reading\n");
        return;
    }

      while (fscanf(file, "%[^\n] %d %d %d %d %d %d %d\n", players[numPlayers].name, &players[numPlayers].pointsScored, &players[numPlayers].steals, &players[numPlayers].assists, &players[numPlayers].blocks, &players[numPlayers].turnovers, &players[numPlayers].shotsMade, &players[numPlayers].shotsAttempted) != EOF) {
        numPlayers++;
    }

    fclose(file);
}